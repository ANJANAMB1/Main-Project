import { useCallback, useRef, useState, useEffect } from "react";
import '../home.css';
import Webcam from "react-webcam";
import Header from '../components/navbar';
import { FaCamera } from "react-icons/fa";
import face from '../assets/face-id.png';
import { Link, Navigate } from "react-router-dom";
import { useAuth } from "../context";

const Home = () => {
    const { userLoggedIn } = useAuth()

    const [file, setFile] = useState(null);
    const [age, setAge] = useState(null);
    const [gender, setGender] = useState(null);
    const [preview, setPreview] = useState(null);

    useEffect(() => {
        if (file) {
            const objectUrl = URL.createObjectURL(file);
            setPreview(objectUrl);
        }
    }, [file]);

    const handleReload = () => {
        window.location.reload();
    };

    const handleUpload = async () => {
        if (file != null) {
            console.log('calling')
            const imageData = new FormData();
            imageData.append('image', file);
            const response = await fetch('http://127.0.0.1:5000/upload', {
                method: 'POST',
                body: imageData,
            });
            console.log('send')

            const data = await response.json();
            setAge(data.result.data['age']);
            setGender(data.result.data['gender']);
        }
    };

    return (
        <div class="parent">
            {!userLoggedIn && (<Navigate to={'/login'} replace={true} />)}

            <div class="child">

                <div class="left">
                    <h3>Age and Gender Detection</h3>
                    <div class="second">
                        <h4>Model</h4>
                        <h4>For</h4>
                        <h4>Age</h4>
                        <h4>&</h4>
                        <h4>Gender</h4>
                        <h4>Detection</h4>
                    </div>
                </div>

                <div class="image-upload">

                    {preview && <img src={preview} alt="Preview" />}
                    {!preview && <label for="fileInput" id="dropArea">
                        <input type="file" id="fileInput" accept="image/*" hidden name="image" onChange={(e) => {
                            setFile(e.target.files[0])
                        }} />
                        <div id="img-view">
                            <p>pick an image</p>
                        </div>
                    </label>
                    }


                </div>

                <div class="right">
                    {/* <h1>SMILE PLEASE.. 😃</h1> */}
                    {preview && <button class="upload" onClick={handleUpload}>
                        Predict 👉
                    </button>
                    }
                    {!preview && <button class="upload">
                        👈 click inside the box
                    </button>
                    }



                    {gender && <h2>This person is a {gender}</h2>}
                    {age && <h2>This person is {age}</h2>}

                    {gender && <button className="upload" onClick={
                        handleReload
                    }>
                        check another 🔃
                    </button>
                    }
                </div>
            </div>
        </div>
    )
}

export default Home