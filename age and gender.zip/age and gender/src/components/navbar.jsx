import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import '../home.css'
import { useAuth } from '../context'
import { doSignOut } from '../firebase/auth'

const Header = () => {

    const navigate = useNavigate()
    const { currentUser } = useAuth()

    const onLogout = async (e) => {
        e.preventDefault()
        await doSignOut();
    }

    return (
        <nav>
            <div class="navleft">
                <h2>Detection</h2>
            </div>
            <div class="navright">
                <ul>
                    <li>
                        <h5>  <Link to={'/'}> Home </Link></h5>
                    </li>

                    <li>
                        <h5 onClick={onLogout}>Logout</h5>
                    </li>
                </ul>
            </div>
        </nav>
    )
}

export default Header